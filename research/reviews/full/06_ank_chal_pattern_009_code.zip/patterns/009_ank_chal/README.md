# 009 Ank-Chal  [naya, 24 Nov 2026 - pushti baaki, paper me chalao]

Kuldeep ke kehne par: "jaise pattern banate hain waise hi, par apne deemak se behtar".
Deep analysis (21,431 DS draw + 4,909 line, 2,040 test, BH + holdout) ke baad jo ek naya asar
aage ke data par bhi tika, wahi ye hai.

## Niyam (ek line me)

**2 draw pehle wale number ka ank (andar ya bahar) aaj usi game me usi jagah aaye = PASS.**

- Andar = dahai ka ank (41 me 4), Bahar = ikayi ka ank (41 me 1).
- Andar/andar aur bahar/bahar alag line hain. Cross (andar se bahar) NAHI - wo random se neeche nikla.
- Har line ka apna hisaab; khelna sirf un line par jahan 13 saal ka rate 10.53% (9.5x ka break-even) se upar ho.

## Kaun si line khelein (2013-2026, 4,907 din)

| Line | Hit | Rate | ROI @9.5x | z | Faisla |
|---|---|---|---|---|---|
| DS andar | 604/4,907 | 12.31% | +16.9% | +5.4 | khelo |
| DS bahar | 575/4,907 | 11.72% | +11.3% | +4.0 | khelo |
| FB andar (FD) | 580/4,907 | 11.82% | +12.3% | +4.3 | khelo |
| GB bahar | 559/4,907 | 11.39% | +8.2% | +3.3 | halka |
| GB andar / GL andar | 537/4,907 | 10.94% | +4.0% | +2.2 | halka |
| GL bahar | 509/4,907 | 10.37% | -1.5% | +0.9 | nahi |
| FB bahar | 498/4,907 | 10.15% | -3.6% | +0.4 | nahi |

Chuni hui 3 line (DS andar, DS bahar, FB andar): **1,759/14,721 = 11.95%, ROI +13.5%**.
Discovery 2013-19: 12.13% | holdout 2020-26: **11.76% (z +5.0)** - yaani aage ke data par bhi tika.
Saal-dar-saal DS andar: 14 me se 10 saal break-even se upar.

## Risk (isse pehle padho)

- 3 ank/din. Jeet wale din 31.6% (mahine me ~9 din), DS 4-number rule me 5.4% (mahine me ~1.6 din).
- 90 din: 270 bet, ~32 hit. Profit ka chance 76%, 5% kharab case -42 unit, median +34 unit.
- Pichhle 90 din (Jun-Nov 2026) sirf 24/270 = 8.9% raha - break-even se neeche. Ye normal jhoola hai, par
  iska matlab bhi hai: 90 din me kuch bhi sabit nahi hota. Faisla 6-12 mahine ke paper par.
- 9.5x par haruf ki katauti/limit jodi se zyada hoti hai. Asli +13% aasani se 0 ho sakta hai.
- 2020 ke baad rate dheere gir raha hai (DS andar 13.9% (2018) se 10.7% (2026)). Isliye monitor zaroori hai.

## Code

`lab/ank_chal.py` - `stats()`, `scan()`, `scoreboard()`, `next_ank()`. Sab kuch sirf paas ka data dekhta hai.
Chalane ke liye: `LAB_DATA_FILE=data/results.csv python3 -m lab.ank_chal`
