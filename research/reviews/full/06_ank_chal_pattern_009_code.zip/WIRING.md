# 009 Ank-Chal ko app me jodne ka tarika (3 chhote edit)

Sab kuch repo ki jad me se chalayein. Har edit ke baad `python3 -m lab.ank_chal` chala kar dekhein ki
number wahi aa rahe hain.

## 1. File rakho
```
lab/ank_chal.py                  <- isi zip se copy
patterns/009_ank_chal/README.md  <- isi zip se copy
```

## 2. lab/scanner.py - teen jagah

(a) line 16 ke aas-paas import me naam jodo:
```python
from . import ank_chal, band, dana_farak, data, steps
```

(b) `PATTERNS = [` list me ek entry jodo (kahin bhi, 005 ke baad theek hai):
```python
    {"id": "009", "key": "ank", "naam": "Ank-Chal", "pushti": False,
     "about": "2 draw pehle wale number ka ank (andar/bahar) usi jagah aaye to PASS. Sirf un line par khelo jahan 13 saal ka rate 10.53% se upar ho: DS andar, DS bahar, FB andar."},
```

(c) `SCANNERS = {...}` me jodo:
```python
SCANNERS = {"steps": steps.scan, "copy": scan_copy, "naksha": scan_naksha, "naksha2": scan_naksha2,
            "family": scan_family, "dana": scan_dana, "ank": ank_chal.scan}
```
`ank_chal.scan(rows, asof=None)` baaki scanner jaisa hi `(rows, asof)` leta hai, isliye `run()` me
kuch badalne ki zarurat nahi.

## 3. lab_server.py - pattern folder ki list

Agar `PATTERN_DIRS` jaisi dict hai (jisme "004" ka folder likha hai), usme jodo:
```python
"009": "009_ank_chal",
```
Iske baad Pattern Scan tab me 009 apne aap roz chalega aur `patterns_today.json` me dikhega.

## 4. (marzi) paper ledger me naya strategy

`lab/paper.py` ke `STRATEGIES` me:
```python
"ank": "Ank-Chal: DS andar+bahar aur FB andar ka lag-2 ank, 9.5x",
```
Aur `place()` ko `payout=9.5` dene ke liye settle() me multiplier per strategy:
```python
MULT = {"ank": 9.5}
mult = MULT.get(b["strategy"], 95 if distinct < 40 else 90)
```
Iske bina `settle()` is strategy ko 95x par ginega - **galat** hoga, kyunki ank ka payout 9.5x hota hai.

## 5. Jaanch (test)

```
LAB_DATA_FILE=data/results.csv python3 -m lab.ank_chal
```
Aana chahiye: DS andar 604/4907 = 12.31%, DS bahar 575/4907 = 11.72%, FB andar 580/4907 = 11.82%,
chuni hui 3 line 1759/14721 = 11.95%, aur aaj ke ank (24 Nov 2026: DS andar 5, DS bahar 9, FB andar 1).

Agar in numbers se mel khata hai to data badal gaya hai (naye din jud gaye) - rate ka aas-paas hona chahiye.
